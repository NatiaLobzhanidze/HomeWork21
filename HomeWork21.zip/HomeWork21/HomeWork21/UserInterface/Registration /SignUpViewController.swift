//
//  SignUpViewController.swift
//  HomeWork21
//
//  Created by Natia's Mac on 14/11/2021.
//

import UIKit
import CoreData

class SignUpViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var errorText: UILabel!
    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var eMail: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var rePassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        

        // Do any additional setup after loading the view.
    }
    
    @IBAction func saveUser(_ sender: Any) {
        if userName.text != "" && eMail.text != "" && password.text != "" && rePassword.text != "" {
            if password.text == rePassword.text{
                
                /// შევამოწმოთ ბაზაში არსებოს  თუ არა მონაცემი ამ იუზერით/ ან მეილით
                ///
                if !registered(with: eMail.text! ){
                  
                    newUserWith(userName: userName.text!, e_mail: eMail.text!, password: password.text!, boolean: true)
                    
                    let sb = UIStoryboard(name: "UserSign", bundle: nil)
                    let vc = sb.instantiateViewController(withIdentifier: "LogInViewController") as! LogInViewController
                    self.present(vc, animated: true, completion: nil)
                    
                    print("Successfully saved")
                } else {
                    errorText.text = "This email address is already being used"
                }
                
            } else{
                errorText.text = " Passwords do not match"
            }
        } else {
            errorText.text = "All Field Are Required"
        }
    }
    
    
    
    func registered(with email: String) -> Bool{
        guard let appDelegate =
           UIApplication.shared.delegate as? AppDelegate else {
             return false
         }
        var boolean: Bool = false
         let managedContext =
           appDelegate.persistentContainer.viewContext
         let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "User")
        fetchRequest.predicate = NSPredicate(format: "mail = %@", email)
         
         do {
             
          let allUser = try managedContext.fetch(fetchRequest)
            
             for users in allUser {
                 if let users = users as? User{
                     if users.mail == email {
                         print("true")
                         boolean =  true
                     } else {
                         boolean =  false
                     }
                 }
             }
         
         } catch let error as NSError {
           print("Could not fetch. \(error), \(error.userInfo)")
         }
        return boolean
    }
    
    
    func newUserWith(userName: String, e_mail: String, password: String, boolean: Bool){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext
    
        let entity = NSEntityDescription.entity(forEntityName: "User", in: context)!
        let user = NSManagedObject(entity: entity, insertInto: context)
        user.setValue(userName, forKey: "userName")
        user.setValue(e_mail, forKey: "mail")
        user.setValue(password, forKey: "password")
        user.setValue(boolean, forKey: "boolean")
        do{
            try context.save()
            print("saved")
          
        }  catch
        {
            let Fetcherror = error as NSError
            print("error", Fetcherror.localizedDescription)
        }

    }

}
