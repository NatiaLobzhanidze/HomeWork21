//
//  LogInViewController.swift
//  HomeWork21
//
//  Created by Natia's Mac on 14/11/2021.
//

import UIKit
import CoreData
protocol LogInViewControllerDelegate: AnyObject {
    func didReceved(data: String)
}

public var user = ""
class LogInViewController: UIViewController {

    @IBOutlet weak var errorLabel: UILabel!
    @IBOutlet weak var mailAdress: UITextField!
    @IBOutlet weak var userSpasword: UITextField!
    
   
    var delegate: LogInViewControllerDelegate? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    

    @IBAction func logInBtn(_ sender: Any) {
        //check
        if mailAdress.text != "" && userSpasword.text != "" {
            
            let dataToSent = self.mailAdress.text
            self.delegate?.didReceved(data: dataToSent!)
            if registered(with: mailAdress.text!, and: userSpasword.text!){
                
                let sb = UIStoryboard(name: "Home", bundle: nil)
                let vc = sb.instantiateViewController(withIdentifier: "firstNC")as! UINavigationController
                vc.modalPresentationStyle = .fullScreen
                self.present(vc, animated: true, completion: nil)
                
            }
        } else {
            errorLabel.text = "wrong"
            showAlertButtonTapped()
        }
       
        
    }
    @IBAction func showAlertButtonTapped() {

           // create the alert
           let alert = UIAlertController(title: "My Title", message: "This is my message.", preferredStyle: UIAlertController.Style.alert)

           // add an action (button)
           alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))

           // show the alert
           self.present(alert, animated: true, completion: nil)
       }
    
    func registered(with mailAdress: String, and pass: String) -> Bool{
        guard let appDelegate =
           UIApplication.shared.delegate as? AppDelegate else {
             return false
         }
        var boolean: Bool = false
         let managedContext =
           appDelegate.persistentContainer.viewContext
         let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "User")
    
         let namePredicate = NSPredicate(format: "mail = %@", mailAdress)
         let passwordPredicate = NSPredicate(format: "password  = %@", pass)
        
        fetchRequest.predicate = NSCompoundPredicate(andPredicateWithSubpredicates: [
            namePredicate,
            passwordPredicate        ]
        )
         do {
             
          let allUser = try managedContext.fetch(fetchRequest)
            
             for users in allUser {
                 if let users = users as? User{
                     if users.mail == mailAdress && users.password == pass {
                         users.setValue(false, forKey: "boolean")
                         print("true")
                         boolean =  true
                     } else {
                         boolean =  false
                     }
                 }
             }
         
         } catch let error as NSError {
           print("Could not fetch. \(error), \(error.userInfo)")
         }
        return boolean
    }

}
