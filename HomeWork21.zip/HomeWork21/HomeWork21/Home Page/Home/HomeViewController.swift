//
//  HomeViewController.swift
//  HomeWork21
//
//  Created by Natia's Mac on 18/11/2021.
//

import UIKit
import CoreData


class HomeViewController: UIViewController, LogInViewControllerDelegate{
    public var articles: [NSManagedObject] = []
    var activeMail = "natia@natia"
    @IBOutlet weak var tableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.register(UINib(nibName: "HomeTableViewCell", bundle: nil),
                           forCellReuseIdentifier: "HomeTableViewCell")
        self.tableView.reloadData()

    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchData()
        tableView.reloadData()
    }
    func didReceved(data: String) {
        self.activeMail = data
    }
    
    @IBAction func logOutBtn(_ sender: Any) {
        let vC = LogInViewController()
        vC.delegate = self
        deactiveUser()
        let sb = UIStoryboard(name: "UserSign", bundle: nil)
        let vc = sb.instantiateViewController(withIdentifier: "LogInViewController") as! LogInViewController
        self.present(vc, animated: true, completion: nil)
        
        
    }
    
    
    func deactiveUser(){
       
     
        guard let appDelegate =
           UIApplication.shared.delegate as? AppDelegate else { return }
    //    var boolean: Bool = true
         let managedContext =
           appDelegate.persistentContainer.viewContext
         let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "User")
        fetchRequest.predicate = NSPredicate(format: "mail = %@", activeMail)
        do {
            
         let allUser = try managedContext.fetch(fetchRequest)
        
            for users in allUser {
                if let users = users as? User{
                    if users.mail == activeMail  && users.boolean == false{
                        print("done")
                        users.setValue(true, forKey: "boolean")
                        try managedContext.save()
                    } else {
                        print("try again")
                    }
                }
            }
        
        } catch let error as NSError {
          print("Could not fetch. \(error), \(error.userInfo)")
        }
    }
    
    func fetchData(){
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest =  NSFetchRequest<NSManagedObject>(entityName: "User")
        
        fetchRequest.predicate = NSPredicate(format: "boolean = %@", false)
         
       
        do {
           articles = try managedContext.fetch(fetchRequest)
            
         }  catch let error as NSError {
          
            print("Could not fetch. \(error), \(error.userInfo)")
            }
        
    }
}


    extension HomeViewController: UITableViewDataSource{
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return articles.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "HomeTableViewCell", for: indexPath)as! HomeTableViewCell
            
            cell.configure(with: articles[indexPath.row])
            return cell
        }
        
    }



