//
//  HomeTableViewCell.swift
//  HomeWork21
//
//  Created by Natia's Mac on 18/11/2021.
//

import UIKit
import CoreData

class HomeTableViewCell: UITableViewCell {
    @IBOutlet weak var author: UILabel!
    @IBOutlet weak var title: UILabel!
    
    @IBOutlet weak var articleText: UILabel!
    @IBOutlet weak var genre: UILabel!
    
    @IBOutlet weak var addDate: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    public func configure( with item: NSManagedObject ){
        author.text = "Author: " + (item.value(forKey: "userName")as? String  ?? " ")
        title.text = "Title: " + (item.value(forKey: "title")as? String  ?? " ")
        articleText.text = item.value(forKey: "article")as?  String
        genre.text = "Genre: " + (item.value(forKey: "genre")as? String  ?? " ")
        addDate.text = "\( item.value(forKey: "date")!)"
    }
}
