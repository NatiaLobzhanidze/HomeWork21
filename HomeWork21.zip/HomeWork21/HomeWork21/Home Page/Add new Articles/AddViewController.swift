//
//  AddViewController.swift
//  HomeWork21
//
//  Created by Natia's Mac on 18/11/2021.
//

import UIKit
import CoreData
class AddViewController: UIViewController {

    @IBOutlet weak var dateData: UIDatePicker!
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var genreTextField: UITextField!
    @IBOutlet weak var addComent: UILabel!
    @IBOutlet weak var articleText: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func addArticle(_ sender: Any) {
        let savedDate = dateData.date
        
        guard let savedTitle = titleTextField.text,
              
              let savedGenre = genreTextField.text,
              let savedText = articleText.text
        else { return }
        
        self.save( date: savedDate, title: savedTitle, genre: savedGenre, text: savedText )
        addComent.text = " New Article Has Been Added, Thank You!"
       
    }
    
    func save(date: Date, title: String, genre: String, text: String) {
      
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext
    
        let entity = NSEntityDescription.entity(forEntityName: "User", in: context)!
        let article = NSManagedObject(entity: entity, insertInto: context)
    
        article.setValue(date, forKeyPath: "date")
        article.setValue(title, forKeyPath: "title")
        article.setValue(genre, forKeyPath: "genre")
        article.setValue(text, forKeyPath: "article")
        
       
      
      do {
        try context.save()
        
      } catch let error as NSError {
        print("Could not save. \(error), \(error.userInfo)")
      }
    }

}
